<p>The Tripal Jobs Management System provides a framework for Biological jobs to be run
via the command-line in order to eliminate the problems associated with long running
jobs in the web browser (ie: timeout errors).</p>