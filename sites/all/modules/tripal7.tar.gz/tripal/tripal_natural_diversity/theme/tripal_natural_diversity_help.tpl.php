<?php ?>

This Tripal module superceeds the tripal_genetic module for display of genotypes on feature and stock pages.  
If you find that your genotype and phenotypes go missing or is changed on feature and stock pages after 
installation of this module this is because those dispays are replaced by data stored in the Natural Diversity 
modules of Chado rather than the original feature_genotype and stock_genotype tables alone. 